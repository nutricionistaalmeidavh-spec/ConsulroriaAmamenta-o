@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0baixar_acervo_expandido.ps1"
pause
