﻿param(
  [string]$Destino = (Join-Path $PSScriptRoot "ARQUIVOS_BAIXADOS")
)
$ErrorActionPreference = "Continue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
New-Item -ItemType Directory -Force -Path $Destino | Out-Null
$csv = Import-Csv (Join-Path $PSScriptRoot "INDICE_ACERVO_EXPANDIDO.csv")

function SafeName([string]$s) {
  $x = $s.Normalize([Text.NormalizationForm]::FormD) -replace '\p{M}',''
  $x = $x -replace '[^A-Za-z0-9 _.-]',''
  $x = $x -replace '\s+','_'
  if ($x.Length -gt 120) { $x = $x.Substring(0,120) }
  return $x
}

function Resolve-PdfFromPage([string]$url) {
  try {
    $r = Invoke-WebRequest -Uri $url -UseBasicParsing -MaximumRedirection 8 -Headers @{"User-Agent"="Mozilla/5.0"}
    $matches = [regex]::Matches($r.Content, 'href\s*=\s*["'']([^"'']+?\.pdf(?:\?[^"'']*)?)["'']', 'IgnoreCase')
    foreach ($m in $matches) {
      $href = [System.Net.WebUtility]::HtmlDecode($m.Groups[1].Value)
      try { return ([uri]::new([uri]$r.BaseResponse.ResponseUri, $href)).AbsoluteUri } catch {}
    }
  } catch {}
  return $null
}

$log = @()
foreach ($i in $csv) {
  if ($i.modo_download -eq 'link_only') {
    $log += [pscustomobject]@{id=$i.id;status='LINK_ONLY';arquivo='';url=$i.url_acesso}
    continue
  }
  $url = $i.url_download
  if ($i.modo_download -eq 'page_pdf') {
    $url = Resolve-PdfFromPage $i.url_acesso
    if (-not $url) {
      $log += [pscustomobject]@{id=$i.id;status='PDF_NAO_LOCALIZADO';arquivo='';url=$i.url_acesso}
      continue
    }
  }
  $name = SafeName("$($i.id)_$($i.titulo)") + '.pdf'
  $out = Join-Path $Destino $name
  try {
    Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing -MaximumRedirection 8 -Headers @{"User-Agent"="Mozilla/5.0"}
    if ((Get-Item $out).Length -lt 1000) { throw 'arquivo pequeno demais' }
    $log += [pscustomobject]@{id=$i.id;status='OK';arquivo=$name;url=$url}
    Write-Host "OK  $($i.id)  $($i.titulo)"
  } catch {
    Remove-Item -ErrorAction SilentlyContinue $out
    $log += [pscustomobject]@{id=$i.id;status='ERRO';arquivo='';url=$url}
    Write-Warning "Falhou $($i.id): $($i.titulo)"
  }
}
$log | Export-Csv (Join-Path $Destino 'LOG_DOWNLOAD.csv') -NoTypeInformation -Encoding UTF8
Write-Host "Concluído. Veja LOG_DOWNLOAD.csv em $Destino"
