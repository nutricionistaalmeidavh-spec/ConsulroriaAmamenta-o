Item 7 - vídeos não produzido, conforme solicitação do usuário.
