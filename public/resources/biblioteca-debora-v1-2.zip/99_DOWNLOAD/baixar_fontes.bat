@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0baixar_fontes.ps1"
