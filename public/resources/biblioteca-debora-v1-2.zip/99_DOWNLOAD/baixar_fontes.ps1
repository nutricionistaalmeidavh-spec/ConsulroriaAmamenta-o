﻿$ErrorActionPreference = "Continue"
$base = Split-Path -Parent $PSScriptRoot
$csv = Import-Csv (Join-Path $PSScriptRoot "fontes_download.csv")
$ok=0; $fail=0; $skip=0
Write-Host "Biblioteca Debora Lactacao - download de fontes" -ForegroundColor Cyan
foreach ($row in $csv) {
  if ([string]::IsNullOrWhiteSpace($row.download_url)) { $skip++; continue }
  $destDir = Join-Path $base $row.folder
  New-Item -ItemType Directory -Force -Path $destDir | Out-Null
  $dest = Join-Path $destDir $row.filename
  if (Test-Path $dest) { Write-Host "[ja existe] $($row.id)" -ForegroundColor DarkGray; $ok++; continue }
  Write-Host "[baixando] $($row.id) - $($row.title)"
  try {
    Invoke-WebRequest -Uri $row.download_url -OutFile $dest -UseBasicParsing -MaximumRedirection 10 -Headers @{"User-Agent"="Mozilla/5.0"}
    if ((Get-Item $dest).Length -lt 1000) { throw "arquivo muito pequeno" }
    $ok++
  } catch {
    Write-Warning "Falhou $($row.id): $($_.Exception.Message)"
    if (Test-Path $dest) { Remove-Item $dest -Force }
    $fail++
  }
}
Write-Host "Concluido. OK=$ok  Falhas=$fail  Apenas-link=$skip" -ForegroundColor Green
Write-Host "Para itens apenas-link, use os atalhos .url das pastas 02/03." -ForegroundColor Yellow
Read-Host "Pressione ENTER para fechar"
