BIBLIOTECA DÉBORA LACTAÇÃO v1.0
Revisado em 23/08/2026

ENTREGAS EXECUTADAS
1. Estrutura e padrão de cadastro
2. Núcleo brasileiro: catálogo + links + baixador automático
3. Fontes internacionais: catálogo + links + baixador automático
4. Matriz de cobertura e lacunas
5. 25 fichas rápidas profissionais
6. 21 guias curtos para mães/famílias
7. Vídeos: OMITIDOS conforme solicitado
8. 8 protocolos internos de avaliação/apoio/encaminhamento
+ 29 infográficos PNG e compilado em PDF

COMO PREENCHER OS PDFs EXTERNOS
Abra 99_DOWNLOAD e execute baixar_fontes.bat em um PC Windows com internet. O script tenta baixar automaticamente todas as fontes com URL PDF direta. Para itens sem URL direta, use os atalhos .url nas pastas 02 e 03.

CRITÉRIO DE ATUALIZAÇÃO
- Referência geral internacional: WHO Model Chapter 2025.
- Brasil: SBP 2024, Ministério da Saúde 2025 (medicamentos), normas e guias atuais quando aplicáveis.
- Mastite/ingurgitamento: ABM #36 (2022) prevalece sobre protocolos ABM antigos #4/#20.
- Medicamentos: não usar lista estática como verdade permanente; conferir MS 2025 + LactMed.

NOTA DE USO
Material de estudo, consulta e apoio. Conteúdos clínicos devem ser aplicados conforme avaliação individual e fontes vigentes.
